/* HTML5 in easy steps:example 58.1 */

function init()
{
  document.getElementById("Browser").value=navigator.appName;
  document.getElementById("Date").value= new Date()
}
onload=init;